function PAR= LoadParameters()
PAR.verbosity=0;
PAR.pixelsamRate=1;
PAR.pyramidLR=4;
PAR.pyramid1to2=4;
PAR.LKhorizon=7;
PAR.horANDvertRatio=1.5;
PAR.LKhorizon1to2=7;
PAR.horANDvertRatio1to2=1;
PAR.tresh=0.0358;

PAR.sigma=6;
PAR.GFsigma=7.67;
PAR.REJtresh=0.53;
PAR.phaseLR=2;
PAR.FLtresh1=0.92;
PAR.REJsigma=6.68;
PAR.phaseLR1=14;
PAR.distTH=0.14;
PAR.BINnum=45;
PAR.blockX=29;
PAR.blockY=5;
PAR.distt=14;
PAR.phaseLR11=45;
end

